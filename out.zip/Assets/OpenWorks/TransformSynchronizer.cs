using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

using UnityEngine.SceneManagement;

using Fusion;

public class TransformSynchronizer : NetworkBehaviour
{
    [Networked] public bool isSceneContent { get; set; }
    [Networked] public string contentAuthor { get; set; }
    [Networked] public string contentMod { get; set; }
    [Networked] public string contentName { get; set; }

    struct locationData : INetworkStruct 
    {
        public Vector3 localPosition;
        public Quaternion localRotation;
    }

    [Networked, Capacity(100)]
    NetworkArray<locationData> locations => default;

    public Transform[] transforms = new Transform[100];

    public Material defaultMaterial;

    private void Start()
    {
        defaultMaterial = new Material(Shader.Find("Universal Render Pipeline/Lit"));
    }
    public override void Spawned()
    {
        //AddBehaviour<NetworkTransform>();
        StartCoroutine(LoadingRoutine());

        base.Spawned();
    }

    IEnumerator LoadingRoutine()
    {
        while (isSceneContent == false && contentName.Length == 0)
            yield return null;


        ContentManager.ModData mod = null;

        print("LOADING 0");

        do
        {
            mod = ContentManager.main.RequestMod(contentAuthor, contentMod);

            if (mod == null)
            {
                yield return null;
                continue;
            }

            break;

        } while (mod == null);

        print("LOADING 1" );
        print(mod);
        if (isSceneContent)
        {
            print("LOADING 2");
            if (ContentManager.main.sceneSynchronizer)
                ContentManager.main.UnloadScene();

            var scene = mod.mod.scenes.FirstOrDefault();
            string sceneName = scene.name;

            scene.Load();
            

            print("LOADING 3");

            var modScene = SceneManager.GetSceneByName(sceneName);

            while (!modScene.isLoaded)
            {
                yield return null;
            }

            ContentManager.main.scene = modScene;
            ContentManager.main.sceneSynchronizer = this;

            PrepareScene(modScene);
        }
        else
        {
            var g = (GameObject)Instantiate(mod.mod.GetAsset(contentName),transform.position, transform.rotation);
            PrepareContent(g);
        }
    }

    int counter = 0;

    public void PrepareScene(Scene scene)
    {
        print("3");
        // Get all root objects in the scene
        GameObject[] rootObjects = scene.GetRootGameObjects();

        print("Objects Loaded " + rootObjects.Length);

        // Loop through each root object
        foreach (GameObject rootObject in rootObjects)
        {
            rootObject.transform.parent = transform;
            ScanGameObject(rootObject);
        }
    }

    public void PrepareContent(GameObject g)
    {
        g.transform.parent = transform;
        ScanGameObject(g);
    }

    // Recursively scans a GameObject and its children
    private void ScanGameObject(GameObject obj)
    {
        print("1");
        if (obj.name.EndsWith("_S"))
        {
            transforms[counter] = obj.transform;
            counter++;
        }

        MeshRenderer meshRenderer = obj.GetComponent<MeshRenderer>();
        if (meshRenderer)
        {
            print("old material : " + meshRenderer.material.shader.name + " | " + "new material : " + defaultMaterial.shader.name);
            meshRenderer.material = defaultMaterial;
        }

        if (!Runner.IsServer)
        {
            var quad_ServerBehaviours = GetComponentsInChildren<IQuad_ServerBehaviour>();

            foreach (var quad_ServerBehaviour in quad_ServerBehaviours)
            {
                Destroy(quad_ServerBehaviour as Component);
            }
        }

        foreach (Transform child in obj.transform)
        {
            ScanGameObject(child.gameObject); // Recursively scan children
        }
    }

    public override void FixedUpdateNetwork()
    {
        if (HasStateAuthority)
        {
            for (int i = 0; i < counter; i++)
            {
                locationData data;
                data.localPosition = transforms[i].localPosition;
                data.localRotation = transforms[i].localRotation;
                locations.Set(i, data);
            }
        }
        else
            for (int i = 0; i < counter; i++)
            {
                transforms[i].SetLocalPositionAndRotation(locations[i].localPosition, locations[i].localRotation);
            }

        base.FixedUpdateNetwork();
    }
}
