﻿
namespace ModIO
{
    public enum ModManagementOperationType
    {
        None_AlreadyInstalled,
        None_ErrorOcurred,
        Install,
        Download,
        Uninstall,
        Update,
        Upload
    }
}
