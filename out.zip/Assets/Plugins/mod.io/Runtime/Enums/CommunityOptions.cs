﻿namespace ModIO
{
    [System.Flags]
    public enum CommunityOptions
    {
        None = 0x00,
        AllowCommenting = 0x01,
    }
}
