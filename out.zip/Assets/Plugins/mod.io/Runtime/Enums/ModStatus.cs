﻿namespace ModIO
{
    public enum ModStatus
    {
        Accepted = 0,
        NotAccepted = 1,
        Deleted = 3
    }
}
