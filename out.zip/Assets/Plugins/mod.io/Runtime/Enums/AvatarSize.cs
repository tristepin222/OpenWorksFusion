﻿namespace ModIO
{
    public enum AvatarSize
    {
        Original,
        Thumbnail_50x50,
        Thumbnail_100x100,
    }
}
