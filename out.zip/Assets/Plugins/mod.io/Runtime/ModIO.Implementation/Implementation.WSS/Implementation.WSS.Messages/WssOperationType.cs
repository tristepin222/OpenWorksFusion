﻿internal static class WssOperationType
{
    public const string Wss_FailedOperation = "failed_operation";
    public const string Wss_DeviceLogin = "device_login";
    public const string Wss_AccessToken = "login_success";
    //...
    public const string Wss_Example = "example";
}
