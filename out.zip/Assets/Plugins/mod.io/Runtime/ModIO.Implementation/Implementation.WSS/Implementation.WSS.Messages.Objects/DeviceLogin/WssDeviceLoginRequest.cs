﻿namespace ModIO.Implementation.Wss.Messages.Objects
{
	[System.Serializable]
	internal struct WssDeviceLoginRequest
	{
		// public string nonce;
	}
}
