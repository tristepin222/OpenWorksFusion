﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Unity.ModIO.Tests")]
