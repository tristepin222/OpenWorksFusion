﻿namespace ModIO.Implementation.API
{
    internal enum WebRequestResponseType
    {
        Text = 0,
        Texture,
        File
    }
}
