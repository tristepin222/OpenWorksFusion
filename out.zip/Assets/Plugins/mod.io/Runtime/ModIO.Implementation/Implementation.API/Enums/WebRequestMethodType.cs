﻿namespace ModIO.Implementation.API
{
    internal enum WebRequestMethodType
    {
        GET,
        POST,
        PUT,
        DELETE
    }
}
