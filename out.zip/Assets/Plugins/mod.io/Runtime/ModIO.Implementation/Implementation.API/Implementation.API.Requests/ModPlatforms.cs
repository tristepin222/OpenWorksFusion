﻿using System;

namespace ModIO.Implementation.API.Objects
{
    [Serializable]
    public struct ModPlatform
    {
        public string platform;
        public int modfileLive;
    }
}
