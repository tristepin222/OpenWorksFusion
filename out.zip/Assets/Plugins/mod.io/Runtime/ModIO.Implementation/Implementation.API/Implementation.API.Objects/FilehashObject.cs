﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    internal struct FilehashObject
    {
        public string md5;
    }
}
