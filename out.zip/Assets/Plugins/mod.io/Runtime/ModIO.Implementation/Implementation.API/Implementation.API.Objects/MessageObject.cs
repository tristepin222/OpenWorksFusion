﻿namespace ModIO.Implementation.API.Objects
{
    internal struct MessageObject
    {
        public long code;
        public string message;
    }
}
