﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    internal struct TermsButtonOptionObject
    {
        public string text;
    }
}
