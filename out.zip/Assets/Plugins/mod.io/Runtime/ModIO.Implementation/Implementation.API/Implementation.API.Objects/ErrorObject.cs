﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    public struct ErrorObject
    {
        public Error error;
    }
}
