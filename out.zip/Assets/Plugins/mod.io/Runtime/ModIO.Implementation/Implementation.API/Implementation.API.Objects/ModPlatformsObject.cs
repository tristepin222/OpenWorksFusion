namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    internal class ModPlatformsObject
    {
        public string platform;
        public int modfile_live;
    }
}
