# Position Debugging

## Documentation

https://doc.photonengine.com/fusion/current/industries-samples/industries-addons/fusion-industries-addons-position-debugging


## Version & Changelog

- Version 2.0.0: First release
