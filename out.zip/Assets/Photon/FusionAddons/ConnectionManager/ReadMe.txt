# ConnectionManager

## Downloads

This addon is included into the `addon project`: https://doc.photonengine.com/fusion/current/industries-samples/industries-addons/fusion-industries-addons-overview

## Version & Changelog

Version 2.0.0: Fusion 2.0 support
Version 1.0.2: Namespace modification
Version 1.0.1: Add namespace
Version 1.0.0: First release 
