﻿namespace ModIO.Implementation
{
    public enum TaskPriority
    {
        HIGH,
        LOW
    }
}
