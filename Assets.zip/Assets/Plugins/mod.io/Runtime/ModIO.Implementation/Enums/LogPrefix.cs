﻿
namespace ModIO.Implementation
{
    internal enum LogPrefix
    {
        Modio,
        ModioInternal,
        ModioAPI,
        ModioGET,
        ModioPOST,
        ModioPUT,
        ModioDELETE
    }
}
