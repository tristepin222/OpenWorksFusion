﻿namespace ModIO.Implementation
{
    public enum ReportResourceType
    {
        Games = 0,
        Mods = 1,
        Users = 2
    }
}
