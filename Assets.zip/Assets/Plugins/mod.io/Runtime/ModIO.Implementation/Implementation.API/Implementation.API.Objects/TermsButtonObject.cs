﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    internal struct TermsButtonObject
    {
        public TermsButtonOptionObject agree;
        public TermsButtonOptionObject disagree;
    }
}
