﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    public struct EntitlementWalletObject
    {
        public int balance;
    }
}
