﻿using System.Collections.Generic;

namespace ModIO.Implementation.API.Objects
{
    internal struct GameTagOptionLocalizationObject
    {
        public string tag;
        public Dictionary<string, string> translations;
    }
}
