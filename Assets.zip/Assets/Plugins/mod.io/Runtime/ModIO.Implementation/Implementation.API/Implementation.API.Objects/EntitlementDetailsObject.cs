﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    public struct EntitlementDetailsObject
    {
        public long tokens_allocated;
    }
}
