﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    internal struct DownloadObject
    {
        public string binary_url;
        public long date_expires;
    }
}
