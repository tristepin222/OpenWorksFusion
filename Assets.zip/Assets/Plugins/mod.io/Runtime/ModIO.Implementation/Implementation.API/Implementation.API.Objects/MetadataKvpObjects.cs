﻿using System;
using ModIO.Implementation.API.Objects;

namespace ModIO
{
    [System.Serializable]
    internal struct MetadataKvpObjects
    {
        public MetadataKvpObject[] data;
    }
}
