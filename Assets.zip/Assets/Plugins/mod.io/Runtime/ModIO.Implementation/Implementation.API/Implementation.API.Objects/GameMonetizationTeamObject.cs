﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    internal struct GameMonetizationTeamObject
    {
        public long team_id;
    }
}
