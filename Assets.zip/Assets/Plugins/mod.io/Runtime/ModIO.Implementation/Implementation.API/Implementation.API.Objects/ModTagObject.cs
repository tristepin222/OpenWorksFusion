﻿namespace ModIO.Implementation.API.Objects
{
    [System.Serializable]
    internal struct ModTagObject
    {
        public string name;
        public string name_localized;
        public string date_added;
    }
}
