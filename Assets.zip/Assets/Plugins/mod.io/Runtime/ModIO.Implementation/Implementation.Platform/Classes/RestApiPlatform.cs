
public enum RestApiPlatform
{
    Windows,
    Mac,
    Linux,
    XboxOne,
    XboxSeriesX,
    Ps5,
    Ps4,
    Switch,
    Uwp,
    Android,
    Ios,
    Oculus,
    Source
}
