namespace Runtime.Enums
{
    public enum ModPriority
    {
        Low = -100,
        Normal = 0,
        High = 100,
        Urgent = 200,
    }
}
