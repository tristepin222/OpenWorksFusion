﻿namespace ModIO
{
    public enum OculusDevice
    {
        Rift,
        Quest
    }
}
