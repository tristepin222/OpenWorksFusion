﻿namespace ModIO
{
    public enum ModRating
    {
        Positive = 1,
        Negative = -1,
        None = 0
    }
}
