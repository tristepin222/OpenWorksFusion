﻿namespace ModIO
{
    public enum PlayStationEnvironment
    {
        spint = 1,
        prodqa = 8,
        np = 256
    }
}
