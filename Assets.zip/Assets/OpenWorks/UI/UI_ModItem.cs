using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_ModItem : MonoBehaviour
{
    [SerializeField] public RawImage image;
    [SerializeField] public TextMeshProUGUI text;
    public string author;
    public string contentName;
    public string modTag;
    public void Click()
    {
        ContentManager.main.ProcessMod(this);
    }
}
